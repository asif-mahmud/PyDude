from cx_Freeze import setup, Executable

includes = ["sip","re","atexit","PyQt4"]

setup(
    name = "PyDudev1.0.0",
    version = "1.0.0",
    description = "Cross Platform avrdude GUI software",
    author = "Asif Mahmud Shimon",
    executables = [Executable(
        script="PyDude.pyw",
        base="Win32GUI")],
    options = {"build_exe" : {"includes" : includes,
                              "icon":"icon.ico",
                              "include_files":["icon.png",
                                               "icon.ico",
                                               "avrdude.exe",
                                               "avrdude.conf",
                                               "gpl-3.0.txt",
                                               "README.txt"]}})
