from cx_Freeze import setup, Executable

includes = ["sip","re","atexit","PyQt4"]
include_files =["icon.png",
                "icon.ico",
                "avrdude",
                "avrdude.conf",
                "README.txt",
                "gpl-3.0.txt"]


setup(
    name = "PyDudev1.0.0",
    version = "1.0.0",
    description = "Cross Platform avrdude GUI software",
    author = "Asif Mahmud Shimon",
    executables = [Executable(
        script="PyDude.pyw")],
    options = {"build_exe" : {"includes" : includes,
                              "icon":"icon.ico",
                              "include_files":include_files}})
