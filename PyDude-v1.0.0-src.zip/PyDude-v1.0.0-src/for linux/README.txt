PyDude v1.0.0
==============================

Avrdude cross platform GUI

Author	: 	Asif Mahmud Shimon
		EEE 09
		Member of Ruet Olympiad Society

mail	:	mailtoshimon@gmail.com



Features 
==============================

GUI interface for avrdude 5.1

Read Actions :

	*Read Flash Memory
	*Read Low Fuse
	*Read High Fuse
	*Read Extended Fuse
	*Read EEPROM Memory

Write Actions :
	
	*Write Flash Memory
	*Write Low Fuse
	*Write High Fuse
	*Write Extended Fuse
	*Write EEPROM Memory

Supports many Programmers & MCUs