from PyQt4.QtGui import *
from PyQt4.QtCore import *

from ReadTab.ReadTab import ReadTab
from WriteTab.WriteTab import WriteTab

import icon_rc

class Tabbed(QMainWindow):
    '''It's the mother window for both read and write tabs'''

    def __init__(self,parent = None):
        super(Tabbed,self).__init__(parent)

        
        
        self.setWindowTitle("PyDude")
        self.setMinimumWidth(640)
        self.t = QTabWidget()
        
        self.wrt = WriteTab()
        self.t.addTab(self.wrt,"Write Actions")
        self.rt = ReadTab()
        self.t.addTab(self.rt,"Read Actions")

        self.setCentralWidget(self.t)

        self.setWindowIcon(QIcon("icon.png"))

    def closeEvent(self,event):
        if QFile.exists("readEep.eep") :
            QFile.remove("readEep.eep")
        if QFile.exists("readHex.hex") :
            QFile.remove("readHex.hex")
        if QFile.exists("readLfuse.txt") :
            QFile.remove("readLfuse.txt")
        if QFile.exists("readHfuse.txt") :
            QFile.remove("readHfuse.txt")
        if QFile.exists("readEfuse.txt") :
            QFile.remove("readEfuse.txt")
