from PyQt4.QtGui import *
from PyQt4.QtCore import *
import subprocess

class ReadTab(QDialog):
    '''MCU Reading operations Here'''

    def __init__(self,parent=None):

        super(ReadTab,self).__init__(parent)

        self.readHexData = None
        self.readEepData = None

        self.l1 = QLabel("<font color = blue size = 5>Select Programmer :</font>")

        self.pgms = QComboBox()
        self.pgms.addItems(["USBasp",
                            "USBtiny",
                            "Atmel AVR ISP",
                            "Atmel AVR ISP V2",
                            "Atmel AVR ISP mkII",
                            "Atmel STK500",
                            "Atmel STK500 Version 1.x",
                            "Atmel STK500 Version 2.x",
                            "Atmel Butterfly",
                            "Atmel JTAG ICE mkII in ISP mode",
                            "Atmel AVR Dragon in ISP mode"])
        self.pgmCodeList = ["usbasp",
                            "usbtiny",
                            "avrisp",
                            "avrispv2",
                            "avrispmkII",
                            "stk500",
                            "stk500v1",
                            "stk500v2",
                            "butterfly",
                            "jtag2isp",
                            "dragon_isp"]

        self.selectedPgmLabel = QLabel("Selected : USBasp")
        self.pgmCode = QLabel("pgm CodeName : usbasp")

        self.l2 = QLabel("<font color = blue size = 5>Select Microcontroller :</font>")

        self.mcus = QComboBox()
        self.mcus.addItems(["ATmega8" ,
                            "ATmega32",
                            "ATtiny10",
			    "ATtiny9",
                            "ATtiny5",
                            "ATtiny4",
                            "32UC3A0512",
                            "ATXMEGA128A4",
                            "ATXMEGA64A4",
                            "ATXMEGA32A4",
                            "ATXMEGA16A4",
                            "ATXMEGA256A3B",
                            "ATXMEGA256A3",
                            "ATXMEGA192A3" ,
                            "ATXMEGA128A3" ,
                            "ATXMEGA64A3" ,
                            "ATXMEGA256A1" ,
                            "ATXMEGA192A1" ,
                            "ATXMEGA128A1REVD" ,
                            "ATXMEGA128A1" ,
                            "ATXMEGA64A1" ,
                            "ATMEGA6450" ,
                            "ATMEGA3250" ,
                            "ATMEGA645" ,
                            "ATMEGA325" ,
                            "ATmega8U2" ,
                            "ATmega16U2" ,
                            "ATmega32U2" ,
                            "AT90USB82" ,
                            "AT90USB162" ,
                            "AT90USB1287" ,
                            "AT90USB1286" ,
                            "AT90USB647" ,
                            "AT90USB646" ,
                            "ATmega32U4" ,
                            "ATtiny84" ,
                            "ATtiny44" ,
                            "ATtiny24" ,
                            "ATMEGA128RFA1" ,
                            "ATMEGA2561" ,
                            "ATMEGA2560" ,
                            "ATMEGA1281" ,
                            "ATMEGA1280" ,
                            "ATMEGA640" ,
                            "ATtiny85" ,
                            "ATtiny45" ,
                            "ATtiny25" ,
                            "AT90PWM3B" ,
                            "AT90PWM2B" ,
                            "AT90PWM3" ,
                            "AT90PWM2" ,
                            "ATtiny4313" ,
                            "ATtiny2313" ,
                            "ATMEGA328P" ,
                            "attiny88" ,
                            "ATMEGA168P" ,
                            "ATMEGA168" ,
                            "ATMEGA88P" ,
                            "ATMEGA88" ,
                            "ATMEGA48" ,
                            "ATTINY861" ,
                            "ATTINY461" ,
                            "ATTINY261" ,
                            "ATTINY26" ,
                            "ATMEGA8535" ,
                            "ATMEGA8515" ,
                            "ATMEGA161" ,
                            "ATMEGA6490" ,
                            "ATMEGA649" ,
                            "ATMEGA3290P" ,
                            "ATMEGA3290" ,
                            "ATMEGA329P" ,
                            "ATMEGA329" ,
                            "ATMEGA169" ,
                            "ATMEGA163" ,
                            "ATMEGA162" ,
                            "ATMEGA1284P" ,
                            "ATMEGA644P" ,
                            "ATMEGA644" ,
                            "ATmega324PA" ,
                            "ATMEGA324P" ,
                            "ATMEGA164P" ,
                            "ATMEGA16" ,
                            "AT90CAN32" ,
                            "AT90CAN64" ,
                            "AT90CAN128" ,
                            "ATMEGA128" ,
                            "ATMEGA64" ,
                            "ATMEGA103" ,
                            "AT90S8535" ,
                            "AT90S8515" ,
                            "AT90S4434" ,
                            "AT90S4433" ,
                            "AT90S2343" ,
                            "AT90S2333" ,
                            "AT90S2313" ,
                            "AT90S4414" ,
                            "AT90S1200" ,
                            "ATtiny15" ,
                            "ATtiny13" ,
                            "ATtiny12" ,
                            "ATtiny11"])
        self.mcuCodeList =     ["m8",
                                "m32",
                                "t10",
				"t9",
				"t5",
				"t4" ,
				"ucr2" ,
				"x128a4" ,
				"x64a4" ,
				"x32a4" ,
				"x16a4" ,
				"x256a3b" ,
				"x256a3" ,
				"x192a3" ,
				"x128a3" ,
				"x64a3" ,
				"x256a1" ,
				"x192a1" ,
				"x128a1d" ,
				"x128a1" ,
				"x64a1" ,
				"m6450" ,
				"m3250" ,
				"m645" ,
				"m325" ,
				"m8u2" ,
				"m16u2" ,
				"m32u2" ,
				"usb82" ,
				"usb162" ,
				"usb1287" ,
				"usb1286" ,
				"usb647" ,
				"usb646" ,
				"m32u4" ,
				"t84" ,
				"t44" ,
				"t24" ,
				"m128rfa1" ,
				"m2561" ,
				"m2560" ,
				"m1281" ,
				"m1280" ,
				"m640" ,
				"t85" ,
				"t45" ,
				"t25" ,
				"pwm3b" ,
				"pwm2b" ,
				"pwm3" ,
				"pwm2" ,
				"t4313" ,
				"t2313" ,
				"m328p" ,
				"t88" ,
				"m168p" ,
				"m168" ,
				"m88p" ,
				"m88" ,
				"m48" ,
				"t861" ,
				"t461" ,
				"t261" ,
				"t26" ,
				"m8535" ,
				"m8515" ,
				"m161",
				"m6490" ,
				"m649" ,
				"m3290p" ,
				"m3290" ,
				"m329p" ,
				"m329" ,
				"m169" ,
				"m163" ,
				"m162" ,
				"m1284p" ,
				"m644p" ,
				"m644" ,
				"m324pa" ,
				"m324p" ,
				"m164p" ,
				"m16" ,
				"c32" ,
				"c64" ,
				"c128" ,
				"m128" ,
				"m64" ,
				"m103" ,
				"8535" ,
				"8515" ,
				"4434" ,
				"4433" ,
				"2343" ,
				"2333" ,
				"2313" ,
				"4414" ,
				"1200" ,
				"t15" ,
				"t13" ,
				"t12" ,
				"t11"]
        self.selectedMcuLabel = QLabel("Selected : ATmega8")
        self.mcuCode = QLabel("mcu CodeName : m8")

        self.l3 = QLabel("<font color = blue size = 5>Select Action :</font>")

        self.readFlash = QCheckBox("Read Flash")
        self.readEeprom = QCheckBox("Read EEPROM Data")
        self.readLfuse = QCheckBox("Read Low Fuse")
        self.readHfuse = QCheckBox("Read High Fuse")
        self.readEfuse = QCheckBox("Read EFuse")

        self.saveHexFile = QPushButton("Save HEX File")
        self.saveEepData = QPushButton("Save EEPROM Data")
        self.go = QPushButton("Go")
        self.credit = QPushButton("Credit")
        self.exit = QPushButton("Exit")
        
        self.left = QVBoxLayout()
        self.left.addWidget(self.l1)
        self.left.addWidget(self.pgms)
        self.left.addWidget(self.selectedPgmLabel)
        self.left.addWidget(self.pgmCode)
        self.left.addStretch()
        self.left.addWidget(self.l2)
        self.left.addWidget(self.mcus)
        self.left.addWidget(self.selectedMcuLabel)
        self.left.addWidget(self.mcuCode)
        self.left.addStretch()
        self.left.addWidget(self.l3)
        self.left.addWidget(self.readFlash)
        self.left.addWidget(self.readLfuse)
        self.left.addWidget(self.readHfuse)
        self.left.addWidget(self.readEfuse)
        self.left.addWidget(self.readEeprom)
        self.left.addStretch()
        self.left.addWidget(self.go)
        self.left.addWidget(self.saveHexFile)
        self.left.addWidget(self.saveEepData)
        self.left.addWidget(self.credit)
        self.left.addWidget(self.exit)


        self.l4 = QLabel("<font color = blue size = 4>HEX file :</font>")
        self.hex = QTextBrowser()
        self.hex.setReadOnly(True)

        self.l5 = QLabel("<font color = blue size = 4>Low Fuse  (0x):</font>")
        self.l6 = QLabel("<font color = blue size = 4>High Fuse (0x):</font>")
        self.l7 = QLabel("<font color = blue size = 4>EFuse     (0x):</font>")

        self.lfuse = QLineEdit()
        self.hfuse = QLineEdit()
        self.efuse = QLineEdit()

        self.lfuse.setReadOnly(True)
        self.hfuse.setReadOnly(True)
        self.efuse.setReadOnly(True)

        self.tmp1 = QHBoxLayout()
        self.tmp1.addWidget(self.l5)
        self.tmp1.addWidget(self.lfuse)

        self.tmp2 = QHBoxLayout()
        self.tmp2.addWidget(self.l6)
        self.tmp2.addWidget(self.hfuse)

        self.tmp3 = QHBoxLayout()
        self.tmp3.addWidget(self.l7)
        self.tmp3.addWidget(self.efuse)

        self.tmp4 = QVBoxLayout()
        self.tmp4.addLayout(self.tmp1)
        self.tmp4.addLayout(self.tmp2)
        self.tmp4.addLayout(self.tmp3)

        self.l8 = QLabel("<font color = blue size = 4>EEPROM Data :</font>")
        self.eeprom = QTextBrowser()
        self.eeprom.setReadOnly(True)

        self.tmp5 = QVBoxLayout()
        self.tmp5.addWidget(self.l8)
        self.tmp5.addWidget(self.eeprom)
        
        self.mid = QHBoxLayout()
        self.mid.addLayout(self.tmp4)
        self.mid.addLayout(self.tmp5)

        self.right = QVBoxLayout()
        self.right.addWidget(self.l4)
        self.right.addWidget(self.hex)
        self.right.addLayout(self.mid)

        self.upper = QHBoxLayout()
        self.upper.addLayout(self.left)
        self.upper.addLayout(self.right)

        self.l5 = QLabel("<font color = blue size = 4>avrdude output :</font>")
        self.dudeOutput = QTextBrowser()
        self.dudeOutput.setReadOnly(True)


        self.progressBar = QProgressBar()
        self.progressBar.setVisible(False)

        
        self.mL = QVBoxLayout()
        self.mL.addLayout(self.upper)
        self.mL.addWidget(self.l5)
        self.mL.addWidget(self.dudeOutput)
        self.mL.addWidget(self.progressBar)

        self.setLayout(self.mL)


        #connections
        #---Label changers---#
        self.connect(self.pgms,
                     SIGNAL("currentIndexChanged(int)"),
                     self.change_pgms_label)
        self.connect(self.pgms,
                     SIGNAL("currentIndexChanged(int)"),
                     self.change_pgms_code_label)
        self.connect(self.mcus,
                     SIGNAL("currentIndexChanged(int)"),
                     self.change_mcu_label)
        self.connect(self.mcus,
                     SIGNAL("currentIndexChanged(int)"),
                     self.change_mcu_code_label)

        #---exit---#
        self.connect(self.exit,
                     SIGNAL("clicked()"),
                     qApp.closeAllWindows)

        #---credit dialog---#
        self.connect(self.credit,
                     SIGNAL("clicked()"),
                     self.show_credit)
        #---perform actions---#
        self.connect(self.go,
                     SIGNAL("clicked()"),
                     self.perform_actions)
        #---save hex file dialog---#
        self.connect(self.saveHexFile,
                     SIGNAL("clicked()"),
                     self.show_save_hex_file_dialog)
        #---save eeprom data file dialog---#
        self.connect(self.saveEepData,
                     SIGNAL("clicked()"),
                     self.show_save_eeprom_data_file_dialog)


    def change_pgms_label(self,index):
        #index holds the selected pgm's index
        self.selectedPgmLabel.setText("Selected : "+self.pgms.currentText())

    def change_pgms_code_label(self,index):
        #index holds the selected pgm's index
        self.pgmCode.setText("pgm CodeName : "+self.pgmCodeList[index])

    def change_mcu_label(self,index):
        #index holds the selected mcu's index
        self.selectedMcuLabel.setText("Selected : "+self.mcus.currentText())

    def change_mcu_code_label(self,index):
        #index holds the selected mcu's index
        self.mcuCode.setText("mcu CodeName : "+self.mcuCodeList[index])


    def show_credit(self):
        QMessageBox.about(self,"About PyDude v1.0.0","<h3><font color = blue>PyDude \
<br>version 1.0.0</font></h3>\
<p><br><br><br>Description : avrdude cross platform GUI \
<br><br>Author : Asif Mahmud Shimon<br>EEE 09<br>Member of <br>\
RUET Olympiad Society<br>\
mailtoshimon@gmail.com</p>")


    def show_save_hex_file_dialog(self):
        if self.readHexData is not None :
            xFilePath = QFileDialog.getSaveFileName(self,
                                        "Save Hex File",
                                        "../untitled.hex",
                                        "hex or HEX (*.hex *.HEX)")
            if xFilePath is not None :
                info = QFileInfo(xFilePath)
                if info.suffix() is None :
                    xFilePath += ".hex"
                xFile = QFile(xFilePath)
                xFile.open(QIODevice.WriteOnly)
                strm = QTextStream(xFile)
                strm<<self.readHexData
                xFile.close()
            
        else :
            QMessageBox.warning(self,
                                "Error",
                                "No Hex Data Found to Save")
            
    def show_save_eeprom_data_file_dialog(self):
        if self.readEepData is not None :
            xFilePath = QFileDialog.getSaveFileName(self,
                                        "Save EEPROM Data File",
                                        "../untitled.eep",
                                        "eep or EEP (*.eep *.EEP)")
            if xFilePath is not None:
                info = QFileInfo(xFilePath)
                if info.suffix() is None :
                    xFilePath += ".eep"
                xFile = QFile(xFilePath)
                xFile.open(QIODevice.WriteOnly)
                strm = QTextStream(xFile)
                strm<<self.readEepData
                xFile.close()
            
        else :
            QMessageBox.warning(self,
                                "Error",
                                "No EEPROM Data Found to Save") 
        

    #---the main attraction here---#
    def perform_actions(self):
        self.go.setEnabled(False)
        self.dudeOutput.setText("")

        #retrieve the mcu code name 
        selectedMcu = self.mcuCodeList[self.mcus.currentIndex()]
        #retrieve the pgm code name 
        selectedPgm = self.pgmCodeList[self.pgms.currentIndex()]

        #Read Flash action
        if self.readFlash.isChecked() :
            xFileName = "readHex.hex"
            command = "sudo avrdude -c " +\
                      selectedPgm +\
                      " -p " +\
                      selectedMcu +\
                      " -U flash:r:" +\
                      xFileName +\
                      ":i"
            tmpText = "<h3><font color = red>Reading flash memory of "
            tmpText += self.mcus.currentText()
            tmpText += "</font></h3><br>"

            pipe = subprocess.Popen(
                    command,
                    stderr=subprocess.PIPE,
                    shell=True)
            strr =""
            self.progressBar.setVisible(True)
            self.progressBar.setMaximum(100)
            self.progressBar.setValue(0)
            count =0
            errorFound = False

            while True :
                    line = pipe.stderr.readline(1)                    
                    if not line :
                        break
                    else :
                        strr+=line
                    if "error" in strr or \
                       "check chip" in strr or \
                       "not defined" in strr or \
                       "not responding" in strr :
                        if not errorFound :
                            QMessageBox.warning(self,
                                               "Error !!!",
                                               "Oops !!!\n\nError happened\nPlease see the console output for more details.")
                            errorFound = True
                        
                    if '#' in line :
                        count+=1
                        self.progressBar.setValue(count)
            tmpText+=strr
            self.dudeOutput.append(tmpText)
            self.progressBar.setVisible(False)
            if count == 100 :
                    QMessageBox.about(self,"PyDude Message","Flash Read successfully.")
                    xFile = QFile(xFileName)
                    xFile.open(QIODevice.ReadOnly)
                    strm = QTextStream(xFile)
                    strr = strm.readAll()
                    self.hex.setText(strr)
                    self.readHexData = str(strr)
                    xFile.close()


        #Read Low Fuse action
        if self.readLfuse.isChecked() :
            xFileName = "readLfuse.txt"
            command = "sudo avrdude -c " +\
                      selectedPgm +\
                      " -p " +\
                      selectedMcu +\
                      " -U lfuse:r:" +\
                      xFileName +\
                      ":i"
            tmpText = "<h3><font color = red>Reading low fuse of "
            tmpText += self.mcus.currentText()
            tmpText += "</font></h3><br>"

            pipe = subprocess.Popen(
                    command,
                    stderr=subprocess.PIPE,
                    shell=True)
            strr =""
            self.progressBar.setVisible(True)
            self.progressBar.setMaximum(100)
            self.progressBar.setValue(0)
            count =0
            errorFound = False

            while True :
                    line = pipe.stderr.readline(1)                    
                    if not line :
                        break
                    else :
                        strr+=line
                    if "error" in strr or \
                       "check chip" in strr or \
                       "not defined" in strr or \
                       "not responding" in strr :
                        if not errorFound :
                            QMessageBox.warning(self,
                                               "Error !!!",
                                               "Oops !!!\n\nError happened\nPlease see the console output for more details.")
                            errorFound = True
                        
                    if '#' in line :
                        count+=1
                        self.progressBar.setValue(count)
            tmpText+=strr
            self.dudeOutput.append(tmpText)
            self.progressBar.setVisible(False)
            if count == 100 :
                    QMessageBox.about(self,"PyDude Message","Low Fuse Read successfully.")
                    xFile = QFile(xFileName)
                    xFile.open(QIODevice.ReadOnly)
                    strm = QTextStream(xFile)
                    strr = strm.readLine()
                    self.lfuse.setText(strr)
                    xFile.close()


        #Read High Fuse action
        if self.readHfuse.isChecked() :
            xFileName = "readHfuse.txt"
            command = "sudo avrdude -c " +\
                      selectedPgm +\
                      " -p " +\
                      selectedMcu +\
                      " -U hfuse:r:" +\
                      xFileName +\
                      ":i"
            tmpText = "<h3><font color = red>Reading high fuse of "
            tmpText += self.mcus.currentText()
            tmpText += "</font></h3><br>"

            pipe = subprocess.Popen(
                    command,
                    stderr=subprocess.PIPE,
                    shell=True)
            strr =""
            self.progressBar.setVisible(True)
            self.progressBar.setMaximum(100)
            self.progressBar.setValue(0)
            count =0
            errorFound = False

            while True :
                    line = pipe.stderr.readline(1)                    
                    if not line :
                        break
                    else :
                        strr+=line
                    if "error" in strr or \
                       "check chip" in strr or \
                       "not defined" in strr or \
                       "not responding" in strr :
                        if not errorFound :
                            QMessageBox.warning(self,
                                               "Error !!!",
                                               "Oops !!!\n\nError happened\nPlease see the console output for more details.")
                            errorFound = True
                        
                    if '#' in line :
                        count+=1
                        self.progressBar.setValue(count)
            tmpText+=strr
            self.dudeOutput.append(tmpText)
            self.progressBar.setVisible(False)
            if count == 100 :
                    QMessageBox.about(self,"PyDude Message","High Fuse Read successfully.")
                    xFile = QFile(xFileName)
                    xFile.open(QIODevice.ReadOnly)
                    strm = QTextStream(xFile)
                    strr = strm.readLine()
                    self.hfuse.setText(strr)
                    xFile.close()

        #Read Extended Fuse action
        if self.readEfuse.isChecked() :
            xFileName = "readEfuse.txt"
            command = "sudo avrdude -c " +\
                      selectedPgm +\
                      " -p " +\
                      selectedMcu +\
                      " -U efuse:r:" +\
                      xFileName +\
                      ":i"
            tmpText = "<h3><font color = red>Reading extended fuse of "
            tmpText += self.mcus.currentText()
            tmpText += "</font></h3><br>"

            pipe = subprocess.Popen(
                    command,
                    stderr=subprocess.PIPE,
                    shell=True)
            strr =""
            self.progressBar.setVisible(True)
            self.progressBar.setMaximum(100)
            self.progressBar.setValue(0)
            count =0
            errorFound = False

            while True :
                    line = pipe.stderr.readline(1)                    
                    if not line :
                        break
                    else :
                        strr+=line
                    if "error" in strr or \
                       "check chip" in strr or \
                       "not defined" in strr or \
                       "not responding" in strr :
                        if not errorFound :
                            QMessageBox.warning(self,
                                               "Error !!!",
                                               "Oops !!!\n\nError happened\nPlease see the console output for more details.")
                            errorFound = True
                        
                    if '#' in line :
                        count+=1
                        self.progressBar.setValue(count)
            tmpText+=strr
            self.dudeOutput.append(tmpText)
            self.progressBar.setVisible(False)
            if count == 100 :
                    QMessageBox.about(self,"PyDude Message","Extended Fuse Read successfully.")
                    xFile = QFile(xFileName)
                    xFile.open(QIODevice.ReadOnly)
                    strm = QTextStream(xFile)
                    strr = strm.readLine()
                    self.efuse.setText(strr)
                    xFile.close()

        #Read EEPROM Data action
        if self.readEeprom.isChecked() :
            xFileName = "readEep.eep"
            command = "sudo avrdude -c " +\
                      selectedPgm +\
                      " -p " +\
                      selectedMcu +\
                      " -U eeprom:r:" +\
                      xFileName +\
                      ":i"
            tmpText = "<h3><font color = red>Reading EEPROM data of "
            tmpText += self.mcus.currentText()
            tmpText += "</font></h3><br>"

            pipe = subprocess.Popen(
                    command,
                    stderr=subprocess.PIPE,
                    shell=True)
            strr =""
            self.progressBar.setVisible(True)
            self.progressBar.setMaximum(100)
            self.progressBar.setValue(0)
            count =0
            errorFound = False

            while True :
                    line = pipe.stderr.readline(1)                    
                    if not line :
                        break
                    else :
                        strr+=line
                    if "error" in strr or \
                       "check chip" in strr or \
                       "not defined" in strr or \
                       "not responding" in strr :
                        if not errorFound :
                            QMessageBox.warning(self,
                                               "Error !!!",
                                               "Oops !!!\n\nError happened\nPlease see the console output for more details.")
                            errorFound = True
                        
                    if '#' in line :
                        count+=1
                        self.progressBar.setValue(count)
            tmpText+=strr
            self.dudeOutput.append(tmpText)
            self.progressBar.setVisible(False)
            if count == 100 :
                    QMessageBox.about(self,"PyDude Message","EEPROM Data Read successfully.")
                    xFile = QFile(xFileName)
                    xFile.open(QIODevice.ReadOnly)
                    strm = QTextStream(xFile)
                    strr = strm.readAll()
                    self.eeprom.setText(strr)
                    self.readEepData = strr
                    xFile.close()
        if not self.readFlash.isChecked() and \
           not self.readLfuse.isChecked() and \
           not self.readHfuse.isChecked() and \
           not self.readEfuse.isChecked() and \
           not self.readEeprom.isChecked() :
            QMessageBox.about(self,
                              "PyDude Message",
                              "<h3>Select an Action first.</h3>")
        
        self.go.setEnabled(True)
