#!/bin/bash
sudo python PyDude.pyw

